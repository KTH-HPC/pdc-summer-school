#include <stdio.h>

void foo();

int main(int argc, char ** argv)
{
    foo();
    return 0;
}