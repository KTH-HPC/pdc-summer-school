#include <stdio.h>

void foo()
{
    printf("Hello from original foo\n");
}