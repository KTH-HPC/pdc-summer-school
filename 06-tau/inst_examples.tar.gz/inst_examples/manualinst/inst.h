#ifndef FOO_H
#define FOO_H

void foo();
void inst_foo();

#define foo inst_foo

#endif /* FOO_H */
