#include <stdio.h>

void foo(void){
    printf("Hello from original libfoo\n");
}