#include <stdio.h>

#include "foo.h"

int main(int argc, char ** argv)
{
    foo();

    return 0;
}