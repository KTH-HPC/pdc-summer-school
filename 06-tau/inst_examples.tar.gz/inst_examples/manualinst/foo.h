#ifndef FOO_H
#define FOO_H

void foo();

#endif /* FOO_H */
