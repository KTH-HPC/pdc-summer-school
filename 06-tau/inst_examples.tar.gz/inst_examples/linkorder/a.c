#include <stdio.h>


void foo()
{
    printf("Hello from foo in %s\n", __FILE__);
}